(() => {
  "use strict";

  const SUPABASE_URL = "https://wojgdfojupnfldrmqaht.supabase.co";
  const PUBLISHABLE_KEY = "sb_publishable_sN7FyjIcTYuhQIMomkzkjA_v4xp3N78";
  const wait = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
  const isClockSkewError = result => /jwt issued at future/i.test(String(result?.msg || result?.message || ""));

  async function sessionDetails() {
    const session = await window.NapiCustomerDirectory?.session?.();
    if (!session?.access_token) throw new Error("A közös adatokhoz csatlakozás szükséges.");
    const tokenPart = session.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    const ownerId = session.user?.id || JSON.parse(atob(tokenPart.padEnd(Math.ceil(tokenPart.length / 4) * 4, "="))).sub;
    return { accessToken: session.access_token, ownerId };
  }

  async function request(resource, { method = "GET", body, prefer = "" } = {}) {
    const { accessToken } = await sessionDetails();
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/${resource}`, {
        method,
        headers: {
          apikey: PUBLISHABLE_KEY,
          Authorization: `Bearer ${accessToken}`,
          Accept: "application/json",
          "Content-Type": "application/json",
          ...(prefer ? { Prefer: prefer } : {})
        },
        ...(body === undefined ? {} : { body: JSON.stringify(body) })
      });
      const text = await response.text();
      const result = text ? JSON.parse(text) : null;
      if (response.ok) return result;
      if (isClockSkewError(result) && attempt < 2) { await wait(attempt ? 2500 : 1200); continue; }
      throw new Error(isClockSkewError(result) ? "Az időellenőrzés miatt a kapcsolat késett. Próbáld meg újra a frissítést." : (result?.message || "A közös mentés most nem érhető el."));
    }
  }

  async function pull() {
    const [configRows, planRows] = await Promise.all([
      request("napi_app_config?select=payload,updated_at&limit=1"),
      request("napi_daily_plans?select=plan_date,payload,updated_at&order=plan_date.desc")
    ]);
    return { config: configRows?.[0] || null, plans: Array.isArray(planRows) ? planRows : [] };
  }

  async function pushConfig(payload) {
    const { ownerId } = await sessionDetails();
    return request("napi_app_config?on_conflict=owner_id", {
      method: "POST",
      body: { owner_id: ownerId, payload, updated_at: new Date().toISOString() },
      prefer: "resolution=merge-duplicates,return=minimal"
    });
  }

  async function pushPlan(plan) {
    const { ownerId } = await sessionDetails();
    return request("rpc/napi_upsert_daily_plan", {
      method: "POST",
      body: { p_owner_id: ownerId, p_plan_date: plan.date, p_payload: plan, p_updated_at: plan.updatedAt || new Date().toISOString() }
    });
  }

  async function deletePlans(dates) {
    const uniqueDates = [...new Set(dates)].filter(Boolean);
    if (!uniqueDates.length) return;
    const filter = uniqueDates.map(date => encodeURIComponent(date)).join(",");
    const currentRows = await request(`napi_daily_plans?select=plan_date,updated_at&plan_date=in.(${filter})`);
    const currentByDate = new Map((currentRows || []).map(row => [row.plan_date, row.updated_at]));
    await Promise.all(uniqueDates.map(date => {
      const currentTimestamp = Date.parse(currentByDate.get(date) || "") || 0;
      const deletedAt = new Date(Math.max(Date.now(), currentTimestamp + 1)).toISOString();
      return pushPlan({ date, deleted: true, updatedAt: deletedAt });
    }));
    const rows = await request(`napi_daily_plans?select=plan_date,payload&plan_date=in.(${filter})`);
    const confirmed = new Set((rows || []).filter(row => row.payload?.deleted).map(row => row.plan_date));
    if (uniqueDates.some(date => !confirmed.has(date))) throw new Error("A teljes nap törlésének közös megerősítése nem sikerült.");
    return rows;
  }

  window.NapiCloudSync = { pull, pushConfig, pushPlan, deletePlans };
})();
